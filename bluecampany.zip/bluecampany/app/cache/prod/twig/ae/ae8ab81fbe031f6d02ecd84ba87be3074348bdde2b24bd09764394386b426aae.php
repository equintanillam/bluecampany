<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_01b43ebdaaf63bf8ac7455e68f27c43fc245e5311f026d6c9e9c7c27b6003317 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_378814be9b73e1b2b3faf822edd01092a1d758b8a4bcc0790a0beadd459bdcc9 = $this->env->getExtension("native_profiler");
        $__internal_378814be9b73e1b2b3faf822edd01092a1d758b8a4bcc0790a0beadd459bdcc9->enter($__internal_378814be9b73e1b2b3faf822edd01092a1d758b8a4bcc0790a0beadd459bdcc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_378814be9b73e1b2b3faf822edd01092a1d758b8a4bcc0790a0beadd459bdcc9->leave($__internal_378814be9b73e1b2b3faf822edd01092a1d758b8a4bcc0790a0beadd459bdcc9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_92fc1e7cc5eca8d49ac6cf28656e56006788c7bda5acd3da88a35043eecc6ead = $this->env->getExtension("native_profiler");
        $__internal_92fc1e7cc5eca8d49ac6cf28656e56006788c7bda5acd3da88a35043eecc6ead->enter($__internal_92fc1e7cc5eca8d49ac6cf28656e56006788c7bda5acd3da88a35043eecc6ead_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_92fc1e7cc5eca8d49ac6cf28656e56006788c7bda5acd3da88a35043eecc6ead->leave($__internal_92fc1e7cc5eca8d49ac6cf28656e56006788c7bda5acd3da88a35043eecc6ead_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_3abfd5a9716f2c2f15b2e7ff94c0b4fd7851ccaf9c108580ae200c84d25a1681 = $this->env->getExtension("native_profiler");
        $__internal_3abfd5a9716f2c2f15b2e7ff94c0b4fd7851ccaf9c108580ae200c84d25a1681->enter($__internal_3abfd5a9716f2c2f15b2e7ff94c0b4fd7851ccaf9c108580ae200c84d25a1681_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_3abfd5a9716f2c2f15b2e7ff94c0b4fd7851ccaf9c108580ae200c84d25a1681->leave($__internal_3abfd5a9716f2c2f15b2e7ff94c0b4fd7851ccaf9c108580ae200c84d25a1681_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_ec6541b9f7638a5438b43ceb846115f1dfbe6873ee9d314b46bcf614423b4856 = $this->env->getExtension("native_profiler");
        $__internal_ec6541b9f7638a5438b43ceb846115f1dfbe6873ee9d314b46bcf614423b4856->enter($__internal_ec6541b9f7638a5438b43ceb846115f1dfbe6873ee9d314b46bcf614423b4856_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_ec6541b9f7638a5438b43ceb846115f1dfbe6873ee9d314b46bcf614423b4856->leave($__internal_ec6541b9f7638a5438b43ceb846115f1dfbe6873ee9d314b46bcf614423b4856_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
