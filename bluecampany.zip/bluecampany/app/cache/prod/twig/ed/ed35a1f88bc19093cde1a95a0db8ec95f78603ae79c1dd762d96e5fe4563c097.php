<?php

/* CalculoBundle:Default:index.html.twig */
class __TwigTemplate_b06010f825fdda993286e6ebae20d0407e9e76b378ce2ef109affe946d91f86c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1184e8d82078a62a4d502c40bc1948522cb78f6967f0e2b52a5c05c70566a70e = $this->env->getExtension("native_profiler");
        $__internal_1184e8d82078a62a4d502c40bc1948522cb78f6967f0e2b52a5c05c70566a70e->enter($__internal_1184e8d82078a62a4d502c40bc1948522cb78f6967f0e2b52a5c05c70566a70e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "CalculoBundle:Default:index.html.twig"));

        // line 1
        echo "<h1>Calculo de Fechas</h1>
";
        // line 2
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "


<h1>Lista Fechas Ingresadas</h1>

<ul>
";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["lista"]) ? $context["lista"] : $this->getContext($context, "lista")));
        foreach ($context['_seq'] as $context["_key"] => $context["listado"]) {
            // line 9
            echo "\t<li>Fecha: ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["listado"], "fecha", array()), "Y-m-d"), "html", null, true);
            echo " | Dias:";
            echo twig_escape_filter($this->env, $this->getAttribute($context["listado"], "dias", array()), "html", null, true);
            echo " | Calculo: </li>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['listado'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "</ul>";
        
        $__internal_1184e8d82078a62a4d502c40bc1948522cb78f6967f0e2b52a5c05c70566a70e->leave($__internal_1184e8d82078a62a4d502c40bc1948522cb78f6967f0e2b52a5c05c70566a70e_prof);

    }

    public function getTemplateName()
    {
        return "CalculoBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 11,  38 => 9,  34 => 8,  25 => 2,  22 => 1,);
    }
}
/* <h1>Calculo de Fechas</h1>*/
/* {{ form(form) }}*/
/* */
/* */
/* <h1>Lista Fechas Ingresadas</h1>*/
/* */
/* <ul>*/
/* {% for listado in lista %}*/
/* 	<li>Fecha: {{listado.fecha|date('Y-m-d') }} | Dias:{{listado.dias}} | Calculo: </li>*/
/* {% endfor %}*/
/* </ul>*/
