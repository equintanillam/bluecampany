<?php

/* base.html.twig */
class __TwigTemplate_7d7fedb1f7287a38f38dddffbad90a4d0bd158668cee5b0438abded0fdf1e414 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a74fef208f8e1174a0efbe2a4619e065084577e660c9dae08cdb541a1989246 = $this->env->getExtension("native_profiler");
        $__internal_9a74fef208f8e1174a0efbe2a4619e065084577e660c9dae08cdb541a1989246->enter($__internal_9a74fef208f8e1174a0efbe2a4619e065084577e660c9dae08cdb541a1989246_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_9a74fef208f8e1174a0efbe2a4619e065084577e660c9dae08cdb541a1989246->leave($__internal_9a74fef208f8e1174a0efbe2a4619e065084577e660c9dae08cdb541a1989246_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_8f52a76484f965d6c6d746c6c4db3de463a8f1ea3f8118b4427fe1ad9b708f54 = $this->env->getExtension("native_profiler");
        $__internal_8f52a76484f965d6c6d746c6c4db3de463a8f1ea3f8118b4427fe1ad9b708f54->enter($__internal_8f52a76484f965d6c6d746c6c4db3de463a8f1ea3f8118b4427fe1ad9b708f54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_8f52a76484f965d6c6d746c6c4db3de463a8f1ea3f8118b4427fe1ad9b708f54->leave($__internal_8f52a76484f965d6c6d746c6c4db3de463a8f1ea3f8118b4427fe1ad9b708f54_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2c044f9e163b8b6376efb58fa14813537836e7fb31b13e744e909443ed134372 = $this->env->getExtension("native_profiler");
        $__internal_2c044f9e163b8b6376efb58fa14813537836e7fb31b13e744e909443ed134372->enter($__internal_2c044f9e163b8b6376efb58fa14813537836e7fb31b13e744e909443ed134372_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_2c044f9e163b8b6376efb58fa14813537836e7fb31b13e744e909443ed134372->leave($__internal_2c044f9e163b8b6376efb58fa14813537836e7fb31b13e744e909443ed134372_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_ca2b715700b277028a0c1e2968be6648f2270b4effb5fad62ea5d66a81b5b28a = $this->env->getExtension("native_profiler");
        $__internal_ca2b715700b277028a0c1e2968be6648f2270b4effb5fad62ea5d66a81b5b28a->enter($__internal_ca2b715700b277028a0c1e2968be6648f2270b4effb5fad62ea5d66a81b5b28a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_ca2b715700b277028a0c1e2968be6648f2270b4effb5fad62ea5d66a81b5b28a->leave($__internal_ca2b715700b277028a0c1e2968be6648f2270b4effb5fad62ea5d66a81b5b28a_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a62585effe56cafc6276c71d4ca0a02d053e5b66f9539557f0a1e5d264972601 = $this->env->getExtension("native_profiler");
        $__internal_a62585effe56cafc6276c71d4ca0a02d053e5b66f9539557f0a1e5d264972601->enter($__internal_a62585effe56cafc6276c71d4ca0a02d053e5b66f9539557f0a1e5d264972601_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_a62585effe56cafc6276c71d4ca0a02d053e5b66f9539557f0a1e5d264972601->leave($__internal_a62585effe56cafc6276c71d4ca0a02d053e5b66f9539557f0a1e5d264972601_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 11,  82 => 10,  71 => 6,  59 => 5,  50 => 12,  47 => 11,  45 => 10,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}Welcome!{% endblock %}</title>*/
/*         {% block stylesheets %}{% endblock %}*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}" />*/
/*     </head>*/
/*     <body>*/
/*         {% block body %}{% endblock %}*/
/*         {% block javascripts %}{% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
