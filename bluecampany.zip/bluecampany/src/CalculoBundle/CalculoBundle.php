<?php

namespace CalculoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CalculoBundle extends Bundle
{
}
