<?php

namespace CalculoBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use CalculoBundle\Entity\Calculos;

class DefaultController extends Controller
{
    public function indexAction(Request $request)
    {
    	//lISTA Fechas Ingresadas

	        $repository = $this->getDoctrine()
	    						->getRepository('CalculoBundle:Calculos');
	 
			$query = $repository->createQueryBuilder('fch')
			    ->orderBy('fch.fecha', 'DESC')
			    ->getQuery();
			 
			$listaFechas = $query->getResult();

		//END LISTA

		//FORMULARIO
	    	$calculo = new Calculos();

	    	$form = $this->createFormBuilder($calculo)
						->add('dias', 'integer')
						->add('fecha', 'date', array(
							    'format' => 'dd-MM-yyyy'
						))
						->add('save', 'submit')
						->getForm();

			//Formulario con datos
			$form->handleRequest($request);

	        if ($form->isValid()) {

	            $em = $this->getDoctrine()->getManager();
	            $em->persist($calculo);
	            $em->flush();


	            //Calcular
	            	$calculado = '';
	            //FinCalcular
	            	
	  
	            return $this->render('CalculoBundle:Default:index.html.twig', array(
					'form' => $form->createView(), 'calculado' => $calculado, 'lista' => $listaFechas
				));
	        }
	        else{
	        	 
	        	 return $this->render('CalculoBundle:Default:index.html.twig', array(
					'form' => $form->createView(), 'lista' => $listaFechas
				));
	        }		

		//END FORMULARIO
 
    }
}
