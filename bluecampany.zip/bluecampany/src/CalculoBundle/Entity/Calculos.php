<?php

namespace CalculoBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Calculos
 */
class Calculos
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var \string
     */
    private $fecha;

    /**
     * @var int
     */
    private $dias;

    /**
     * @var \string
     */
    private $fechaFinal;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fecha
     *
     * @param \string $fecha
     * @return Calculos
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \string 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set dias
     *
     * @param integer $dias
     * @return Calculos
     */
    public function setDias($dias)
    {
        $this->dias = $dias;

        return $this;
    }

    /**
     * Get dias
     *
     * @return integer 
     */
    public function getDias()
    {
        return $this->dias;
    }

    /**
     * Set fechaFinal
     *
     * @param \string $fechaFinal
     * @return Calculos
     */
    public function setFechaFinal($fechaFinal)
    {
        $this->fechaFinal = $fechaFinal;

        return $this;
    }

    /**
     * Get fechaFinal
     *
     * @return \string 
     */
    public function getFechaFinal()
    {
        return $this->fechaFinal;
    }
}
