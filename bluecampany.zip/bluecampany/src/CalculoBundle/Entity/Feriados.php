<?php

namespace CalculoBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Feriados
 */
class Feriados
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var \string
     */
    private $fecha;

    /**
     * @var string
     */
    private $motivo;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fecha
     *
     * @param \string $fecha
     * @return Feriados
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;

        return $this;
    }

    /**
     * Get fecha
     *
     * @return \string 
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * Set motivo
     *
     * @param string $motivo
     * @return Feriados
     */
    public function setMotivo($motivo)
    {
        $this->motivo = $motivo;

        return $this;
    }

    /**
     * Get motivo
     *
     * @return string 
     */
    public function getMotivo()
    {
        return $this->motivo;
    }
}
